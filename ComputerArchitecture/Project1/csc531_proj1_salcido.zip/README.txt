CSC 531-01
Spring 2020
Project 1
Angel Salcido

The program works correctly.

How to execute:
(1) Load source into qtSpim application
(2) Run program
(3) input number of array elements user will submit
(4) input element values